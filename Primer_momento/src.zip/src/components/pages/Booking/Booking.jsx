const Booking=()=>{

    return(
        <>
        <h1>Booking</h1>
        </>
    )
}

export default Booking